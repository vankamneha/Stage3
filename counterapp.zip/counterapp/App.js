import React, { Component } from 'react';
import './index.css';
import OnlineShopping from './OnlineShopping';
class App extends Component {

  
  render() {
    return (
      <div>
        <OnlineShopping />
      </div>
    )
  }
}
export default App;