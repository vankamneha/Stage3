function App(){
  return(
    <h1>Welcome the first session of React</h1>
  );
}
export default App;