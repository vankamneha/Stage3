import React, {Component} from 'react';
class About extends Component{
    render()
    {
        return(
            <div>
                <h3>Welcome to the About page of Student Management Portal</h3>
            </div>
        )
    }

}
export default About