function GuestGreeting(props){
    return <h1>Please sign up.</h1>
}
export default GuestGreeting;