const T20Players=["First Player",
    "Second Player",
    "Third Player"
];
const RanjiTrophyPlayers=["Fourth Player",
    "Fifth Player",
    "Sixth Player"];
export const IndianPlayers=[...T20Players,...RanjiTrophyPlayers];