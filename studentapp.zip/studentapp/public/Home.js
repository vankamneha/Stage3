import React,{Component} from 'react';
import class Home extends Component{
    render(){
        <div>
        <h3>Welcome to the Home Page of Student Management Portal</h3>
        </div>
    }
}