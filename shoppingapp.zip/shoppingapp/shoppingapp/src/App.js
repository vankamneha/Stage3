import React ,{Component} from 'react';
import OnlineShopping from './online_shopping/Online_shopping';
import './App.css';
class App extends Component{
  render(){

    return(
      <div className="App">
        <OnlineShopping/>
      </div>
      
    )
  }
}
export default App;