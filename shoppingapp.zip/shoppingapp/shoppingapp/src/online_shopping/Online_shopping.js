import React ,{Component} from 'react';
import CartItem from '../cart_item/Cart_item';
class OnlineShopping extends Component{
  render(){

    const cartInfo=[
        {itemName:'TV',price:300},
        {itemName:'Washing machine',price:400},
        {itemName:'AC',price:500},
        {itemName:'Fan',price:600}
    ]

    return(
        <div className="Cart">
            <CartItem CartItems={cartInfo}/>

        </div>
    )
  }
}
export default OnlineShopping;